<?php

namespace App\Models;

use App\Models\Reserva;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Invitado extends Model
{
    use HasFactory;

    protected $table = "invitados";

    protected $primaryKey = "id";

    protected $fillable = [
        "email",
        "nombre",
        "apellidos",
        "telefono",
    ];


    public function reserva(){
        return $this->hasMany(Reserva::class,"id");
    }
}
