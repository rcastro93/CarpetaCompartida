<?php
namespace App\Models;

use Illuminate\Support\Facades\Auth;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Reserva extends Model
{
    use HasFactory;
    protected $table = 'reservas';
    protected $primaryKey = 'id';
    protected $fillable = [
        'id_cliente',
        'id_invitado',
        'id_menu',
        'id_mesa',
        'num_tarjeta',
        'fecha_reserva',
        'num_personas',
    ];

    public function cliente(){
        return $this->belongsTo(User::class,"id_cliente");
    }

    public function horario(){
        return $this->belongsTo(Horario::class,"fecha_reserva");
    }

    public function invitado(){
        return $this->belongsTo(Invitado::class,"id_invitado");
    }

    public static function buscarReservas(){
        $busqueda = Invitado::where('email', Auth::user()->email)->get();
        // dd($busqueda->first()->id);
        if ($busqueda->isEmpty()) {
            # code...
            // dd("IF");
            return Reserva::where('id_cliente', Auth::user()->id)->get();
        } else {
            // dd($busqueda);
            // dd($busqueda->first()->id);
            // dd("ELSE");
            $prueba = Reserva::where('id_invitado', $busqueda->first()->id)->orWhere('id_cliente', Auth::user()->id)->get();
            // dd($prueba);
            return $prueba;
        }
        // dd(Invitado::where('email', Auth::user()->email)->get());
        // return Reserva::where('id_cliente', Auth::user()->id)->get();
    }
    public function menuReservado(){
        // dd('');
        return $this->belongsTo(Menu::class,"id_menu");
    }

    public static function eliminarReserva($id){
        // return Reserva::
    }

}
