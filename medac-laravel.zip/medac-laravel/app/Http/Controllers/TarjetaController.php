<?php

namespace App\Http\Controllers;

use App\Models\Tarjeta;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class TarjetaController extends Controller
{
    //

    public function addTarjetaVista(){
        return view('addTarjeta');
    }

    public function addTarjeta(Request $request){
        Tarjeta::create([
            "num_tarjeta" => $request->post('num_tarjeta'),
            "anyo_caducidad" => $request->post('anyo_caducidad'),
            "mes_caducidad" => $request->post('mes_caducidad'),
            "cvv" => $request->post('num_tarjeta'),
            "id_cliente" => Auth::user()->id,

        ]);
        return view('index');
    }
}
