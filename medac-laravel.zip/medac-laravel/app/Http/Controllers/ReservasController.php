<?php

namespace App\Http\Controllers;

use App\Models\Menu;
use App\Models\User;
use App\Models\Horario;
use App\Models\Reserva;
use App\Models\Tarjeta;
use App\Models\Invitado;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ReservasController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        // return view("misReservas");
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //


    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        //  dd($request->post("comensales"));

        // validar los datos siempre antes
        // $this->validate($request, [
        //     'nombre' => 'required|min:5|max:30',
        //     'email' => 'required|email',
        //     'fecha' => 'required',
        //     'telefono' => 'required',
        //     'comensales' => 'required',
        // ]);

        Reserva::create([
            'num_personas' => $request->post('comensales'),
            'fecha_reserva' => $request->post('horario'),
            'id_menu' => $request->post('menu'),
            'id_invitado' => null,
            'num_tarjeta' => $request->post('tarjeta'),
            'id_mesa' => "1",
            'id_cliente' => Auth::user()->id,
        ]);
        $mensaje = "Se ha confirmado tu reserva, esperamos que tengas hambre";
        $update = Horario::where('id', $request->post('horario'))->get();
        // dd($update);
        $update[0]->update(['estado' => 'reservado']);
        return redirect("/misReservas")->with("mensaje", $mensaje);
        // dd($request);
    }

    public function store2(Request $request)
    {
        //
        //  dd($request->post("comensales"));

        // validar los datos siempre antes
        // $this->validate($request, [
        //     'nombre' => 'required|min:5|max:30',
        //     'email' => 'required|email',
        //     'fecha' => 'required',
        //     'telefono' => 'required',
        //     'comensales' => 'required',
        // ]);
        // dd($request->post('menu'));
        Invitado::create([
            "email" => $request->post('email'),
            "nombre" => $request->post('nombre'),
            "apellidos" => $request->post('apellidos'),
            "telefono" => $request->post('telefono'),
        ]);
        $num_tarjeta = $request->post('num_tarjeta');
        $mes = $request->post('mes_caducidad');
        $anyo = $request->post('anyo_caducidad');
        $cvv = $request->post('cvv');
        $tarjeta = ['num_tarjeta' => $num_tarjeta, 'mes' => $mes, 'anyo' => $anyo, 'cvv' => $cvv];
        $usuarioPrueba =  Invitado::where('email', $request['email'])->get();
        Reserva::create([
            'num_personas' => $request->post('comensales'),
            'fecha_reserva' => $request->post('horario'),
            'id_menu' => $request->post('menu'),
            'id_invitado' => $usuarioPrueba[0]->id,
            'num_tarjeta' => $request->post('num_tarjeta'),
            'id_mesa' => "1",
            'id_cliente' => null,
        ]);
        $reservaPrueba = Reserva::where('id_invitado', $usuarioPrueba[0]->id)->get();
        $resultados = [$tarjeta, $reservaPrueba];
        $update = Horario::where('id', $request->post('horario'))->get();
        // dd($update);
        $update[0]->update(['estado' => 'reservado']);
        // dd($reservaPrueba);
        // dd($request->post('menu'));
        return view('bienvenidaInvitado', ['resultados' => $resultados]);
        // dd($request);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Reserva $Reserva)
    {
        $Reserva->delete();
        return back();
    }

    public function generarReservas()
    {
    }

    public function buscarReservas()
    {
        $mensaje = Reserva::buscarReservas();
        // dd($mensaje);
        return view('misReservas', ['reservas' => $mensaje]);
        // return view ('misReservas')->with ("reservas" => User::all());
    }

    public function generarReserva()
    {
        $mensaje = Menu::recogerMenus();
        $mensaje2 = Horario::recogerHorario();
        $prueba = ["menus" => $mensaje, "horarios" => $mensaje2];
        return view('confirmar', ['prueba' => $prueba]);
        // return view ('misReservas')->with ("reservas" => User::all());
    }

    public function generarReservaInvitado()
    {
        $mensaje = Menu::recogerMenus();
        $mensaje2 = Horario::recogerHorario();
        $prueba = ["menus" => $mensaje, "horarios" => $mensaje2];
        return view('confirmarInvitado', ['prueba' => $prueba]);
    }

    public function cerrarSesion()
    {
        Auth::logout();
        return view('index');
    }
}
