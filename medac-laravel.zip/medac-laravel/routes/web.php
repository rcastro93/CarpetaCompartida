<?php
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\TarjetaController;
use App\Http\Controllers\ContactoController;
use App\Http\Controllers\ReservasController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\RegisterController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/', function () {
    return view('index');
});
Route::get('/reserva', function () {
    return view('confirmar');
});
// Route::get('/registro', function () {
//     return view('registro');
// });
Route::get('/areaPersonal', function () {
    return view('areaPersonal');
});
Route::get('/bienvenidaInvitado', function () {
    return view('bienvenidaInvitado');
});
Route::get('/login2', function () {
    return view('login2');
});
Route::get('/success', function () {
    return view('success');
});
Route::get('/contacto', function () {
    return view('contacto');
});
Route::get('/misReservas', function () {
    return view('misReservas');
});
// Route::get('/contacto', [ContactoController::class,'index']);
Route::post('/contacto', [ContactoController::class,'store']);
Route::post('/success', [ReservasController::class,'store']);
Route::post('/success2', [ReservasController::class,'store2']);
Auth::routes();
Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('index');
Route::get('/entrar', [LoginController::class, 'index']);
Route::post('/registrarTarjeta', [TarjetaController::class, 'addTarjeta'])->name('addTarjeta');
Route::get('/addTarjeta', [TarjetaController::class, 'addTarjetaVista'])->name('addTarjetaVista');
Route::get('/registro', [RegisterController::class, 'index']);
Route::get('/misReservas', [ReservasController::class, 'buscarReservas']);
Route::get('/confirmar', [ReservasController::class, 'generarReserva']);
Route::get('/confirmarInvitado', [ReservasController::class, 'generarReservaInvitado']);
Route::get('/prueba', [ReservasController::class, 'cerrarSesion']) -> name('login.delete');
Route::delete('/misReservas/{Reserva}',[ReservasController::class, 'destroy']) -> name('reserva.delete');
