<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e(__('Registrarse')); ?></div>

                    <div class="card-body">
                        <form method="post" action="<?php echo e(route('addTarjeta')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="col-md-6">
                                <label for="password-confirm"
                                    class="col-md-4 col-form-label text-md-end"><?php echo e(__('Numero Tarjeta')); ?></label>

                                <input placeholder="NUMERO TARJETA" id="num_tarjeta" type="number"
                                    class="mb-2 form-control <?php $__errorArgs = ['num_tarjeta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="num_tarjeta"
                                    required autocomplete="num_tarjeta">
                                <label for="password-confirm"
                                    class="col-md-4 col-form-label text-md-end"><?php echo e(__('Mes Caducidad')); ?></label>

                                <input placeholder="MES CADUCIDAD" id="mes_caducidad" type="number"
                                    class="mb-2 form-control <?php $__errorArgs = ['mes_caducidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="mes_caducidad" required autocomplete="mes_caducidad">
                                <label for="password-confirm"
                                    class="col-md-4 col-form-label text-md-end"><?php echo e(__('Año Caducidad')); ?></label>

                                <input placeholder="AÑO CADUCIDAD" id="anyo_caducidad" type="number"
                                    class="mb-2 form-control <?php $__errorArgs = ['anyo_caducidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="anyo_caducidad" required autocomplete="anyo_caducidad">
                                <label for="password-confirm"
                                    class="col-md-4 col-form-label text-md-end"><?php echo e(__('CVV Caducidad ')); ?></label>

                                <input placeholder="CVV" id="cvv" type="number"
                                    class="mb-2 form-control <?php $__errorArgs = ['cvv'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="cvv" required
                                    autocomplete="cvv">
                            </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6 offset-md-4 ">
                            <button type="submit" class="btn btn-primary">
                                <?php echo e(__('Registrarse')); ?>

                            </button>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medac-laravel\resources\views/addTarjeta.blade.php ENDPATH**/ ?>