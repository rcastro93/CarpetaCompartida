<?php $__env->startSection('content'); ?>
    <main class="text-center">
        <section class="row">
            <div class="col-md-12 justify-content-center">
                <h1 class="col-md-12 text-center mt-5">¿Quieres vivir una experiencia gastronomica sin igual?</h1>
            </div>
            <div>
                <p> Os damos la bienvenida al sistema de reservas de Noor. No dude en contactar con nosotros para
                    acompañarle en cualquier punto del proceso de reserva.</p>
            </div>
            <div class="row claseDelDiv justify-content-around" ">
                                <div class="bg-light w-25 h-50 mt-5 col-md-3">
                                    <div class="descripCalendar">
                                        <p>Elige una fecha en la que visitarnos</p>
                                        <input type="date" name="begin" placeholder="dd-mm-yyyy" value="" min="1997-01-01" max="2030-12-31" class="p-12">
                                    </div>
                                    <div class="calendario">
                                        <p>Calendario</p>
                                    </div>
                                    <div class="botonConfirmar"><a href="/confirmar">Confirmar</a></div>
                                </div>
                                <div class="col-md-7">
                                    <img src="./img/reserva1.jpg" alt="">
                                </div>
                            </div>
                        </section>
                    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medac-laravel\resources\views/reserva1.blade.php ENDPATH**/ ?>