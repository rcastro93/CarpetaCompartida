<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/app.css">
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous"> -->
    <link rel="stylesheet" href="CSS/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@200&display=swap" rel="stylesheet">
    <!-- <link rel="stylesheet" href="CSS/normalize.css"> -->

    <title>noor Restaurant</title>
</head>

<body>
    <header>
        <nav class="headerDiv">
            <input type="checkbox" id="minimenu">
            <label for="minimenu">&#9776;</label>
            <div class="logoPrincipal">
                <a href="index.html"> <img src="img/logo-sinfondoplano.png" alt=""></a>
            </div>
            <ul>
                <div class="Reserva">
                    <li><a href="reserva1.html">Reservar</a></li>
                </div>
                <div class="Contacto">
                    <li><a href="login.html">Iniciar Sesion</a></li>
                </div>
            </ul>
        </nav>
    </header>
    <main class="text-center">
        <section class="col  display-3">
            <div>
                <h1 class="mt-7 mb-5">Bienvenido a noor</h1>
                <img class="img-fluid" src="img/restBienvenida.jpg" alt="restaurante">
            </div>
        </section>
        <section class="intro row">
            <div class="col-md-11 text-center">
                <p class="mt-5">En 2016 el chef cordobés Paco Morales ilumina Noor con la vuelta a su Córdoba natal, a sus
                    orígenes,
                    para alumbrar una propuesta única y personal de cocina contemporánea andalusí. El legado
                    culinario de Al-Ándalus recuperado
                    en clave contemporánea.
                    <br>
                    La propuesta culinaria se inspira en la historia y el pensamiento de las culturass,
                    cuyo hito capital fue el Califato de Abderramán III, que convirtió Córdoba en la ciudad más
                    culta y avanzada de su época.
                </p>
            </div>
            <div class="col-md-12 text-center">
                <img class="img-fluid mt-5" src="img/introimg.jpg" alt="introimg">
            </div>
        </section>
        <section class="display-1">
            <div>
                <p class="mt-5">TEMPORADAS</p>
            </div>
        </section>
        <section class="row justify-content-center">
            <div><img class="img-fluid" src="img/alandalus.png" alt="Al-Ándalus"></div>
            <div class="col-md-11 ">
                <p class="mt-5">Temporada inmersa en la culinaria andalusí del siglo X, etapa de esplendor político,
                    cultural y comercial propiciada por el Califato de Córdoba. Noor inició su propio universo
                    particular a
                    través de tres menús degustación: Qurtuba, Madinat Al-Zahra y Al-Ándalus</p>.
            </div>
            <div><img class="img-fluid mt-5" src="img/alandaluscomida.jpg" alt="alandaluscomida"></div>
        </section>
        <section class="col">
            <div><img class="img-fluid mt-5" src="img/taifas.png" alt="taifas"></div>
            <div class="row justify-content-center">
                <p class="col-md-11 text-center mt-5">Noor continúa su avance en el tiempo. En este año 1 recupera los
                    <span>sabores perdidos</span> de los tres Reinos
                    de Taifas, y sus culturas, que más perduraron tras la disolución y caída del Califato de Córdoba en
                    1031. Son los que dan nombre a las<span>tres alternativas de menú</span>:
                    <span>Eslava, Bereber y Andalusí</span>.
                </p>
            </div>
            <div class="row justify-content-around">
                <img class="col-md-11 img-fluid w-80 mb-2 rounded mt-5" src="img/taifascomida1.jpg" alt="">
                <div class="col-5">
                    <span></span>
                </div>
                <img class="col-md-11 img-fluid w-80 rounded" src="img/taifascomida2.jpg" alt="">
            </div>
        </section>
        <section class="nazari">
            <div><img class="img-fluid mt-5" src="img/nazari.png" alt="nazari"></div>
            <div class="descrip">
                <p class="col-md-11 text-center mt-5">
                Noor conserva su línea de no integrar ingredientes del Nuevo Mundo americano en su cocina del siglo XIV
                que, aún sin patata, tomate, maíz o cacao ... da un
                <span>último salto mortal</span>
                para que su propuesta
                gastronómica continúe tan
                <span>inigualable y rotunda</span>
                como en el Año 1.</p>
            </div>
            <div><img class="img-fluid mb-2 mt-5" src="img/nazarifood.jpg" alt=""></div>
            <div><img class="img-fluid" src="img/nazarifood2.jpg" alt=""></div>
        </section>
    </main>
    <footer>
        <div class="namefooter">
            <p>
            <nav>
                <a href="index.html">Noor Restaurant</a>
            </nav>
            </p>
        </div>
        <div class="footernav">
            <p>
            <nav>
                <a href="#">Trabaja con Nosotros</a>
                <a href="#">Encuentranos</a>
                <a href="#">Redes Sociales</a>
            </nav>
            </p>
        </div>
    </footer>
</body>

</html><?php /**PATH C:\xampp\htdocs\resources\views/index.blade.php ENDPATH**/ ?>