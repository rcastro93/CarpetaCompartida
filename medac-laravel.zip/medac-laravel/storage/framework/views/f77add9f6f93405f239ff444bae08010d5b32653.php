<?php $__env->startSection('content'); ?>
<?php
        // print_r($prueba['horarios']);
        $guardado = [];
        foreach ($prueba as $a) {
            # code...
            foreach ($a as $key ) {
                # code...
                if ($key->fecha != "") {
                    # code...
                    array_push($guardado, $key->fecha);
                }
            }
        }
        // print_r($guardado)
        $events = json_encode($guardado);
  // Almacenar en SessionStorage
  echo "<script>sessionStorage.setItem('events', '$events');</script>";

    ?>
    <script>
        var events = JSON.parse(sessionStorage.getItem('events'));
// console.log(events);
        // console.log($prueba);
        let prueba2 = [];
        for (let index = 0; index < events.length; index++) {
            // console.log(events[0]);
            prueba2.push({
                id: events[index],
                title: 'DISPONIBLE',
                start: events[index],
                end: events[index],
                allDay: true,
            });
        }
        console.log(prueba2);
        document.addEventListener('DOMContentLoaded', function() {

            var calendarEl = document.getElementById('calendar');
            var calendar = new FullCalendar.Calendar(calendarEl, {
                events: prueba2,

                customButtons: {
                    myCustomButton: {
                        text: 'custom',
                        click: function() {
                            alert('clicked the custom button!');
                        }
                    }
                },
                buttonIcons: {
                    prev: 'left-single-arrow',
                    next: 'right-single-arrow',
                },
                eventContent: function(eventInfo) {
                    var backgroundColor = 'green';
                    var borderColor = 'green';
                    var textColor = 'white';
                    return {
                        html: `<div style='background-color:${backgroundColor};color:${textColor};'>${eventInfo.event.title}</div>`
                    };
                },
                eventClick: function(info) {
                    alert('Event: ' + info.event.title);
                },
            });
            calendar.render();
        });
    </script>
    <main>
        <div class="mainConfirmacion row">
            <section class="col-12 col-md-6">
                <div class="mensajeConfirmacion">
                    
                    <br>
                    <p class="">
                        
                        <br><br>
                        Rellene los formularios y confirmaremos
                        su <br><b>reserva</b>
                    </p>
                </div>

            </section>
            <section class="col-12 col-md-6 bg-light text-dark ">
                <form action="/success" method="post" class="row justify-content-center">
                    <?php echo csrf_field(); ?>
                    <div class="text-center">
                        <p>Seleccione el turno de servicio y la cantidad de comensales</p>
                        <label class="comensaleslabel mb-3" for="turno-servicio">Selecciona tu menu:</label>
                        <select name="menu" class="seleccion w-25">
                            <?php $__currentLoopData = $prueba["menus"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($valor->id); ?>"><?php echo e($valor->nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <br>
                        <label class="comensaleslabel mb-3" for="turno-servicio">Selecciona tu tarjeta:</label>
                        <select name="tarjeta" class="seleccion w-25">
                            <?php $__currentLoopData = auth()->user()->tarjetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value=" <?php echo e($valor->num_tarjeta); ?> "><?php echo e($valor->num_tarjeta); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <br>
                        <label class="comensaleslabel mb-3" for="turno-servicio">Selecciona tu horario:</label>
                        <br>
                        <select class="w-90 p-3" name="horario" class="seleccion">
                            <?php $__currentLoopData = $prueba["horarios"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($valor->id); ?>"><?php echo e($valor->fecha); ?> / <?php echo e($valor->hora); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <br>
                        <br>
                        <label class="comensaleslabel mb-3" for="cantidad-comensales">Selecciona el número de
                            Comensales:</label>
                        <select name="comensales" class="cantidad-comensal w-25">
                            <option value="0">--</option>
                            <option value="1">Uno</option>
                            <option value="2">Dos</option>
                            <option value="3">Tres</option>
                            <option value="4">Cuatro</option>
                            <option value="5">Cinco</option>
                            <option value="6">Seis</option>
                        </select>
                    </div>
                    <div>
                        <?php if(auth()->user()): ?>
                            <label class="comensaleslabel mt-2 mb-2" for="cantidad-comensales">E-mail</label>
                            <input style="font-weight: bold" type="email" readonly class="form-control-plaintext font-weigth-bold" id="floatingInput" name="email"
                                placeholder="Introduce tu email" value="<?php echo e(auth()->user()->email); ?>">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="alert alert-danger mt-2"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <label class="comensaleslabel mt-2 mb-2" for="cantidad-comensales">Nombre</label>
                            <input style="font-weight: bold" type="text" readonly class="form-control-plaintext" id="floatingPassword" name="nombre"
                                placeholder="Introduce tu Nombre" value="<?php echo e(auth()->user()->name); ?>">
                            <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="alert alert-danger mt-2"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <label class="comensaleslabel mt-2 mb-2" for="cantidad-comensales">Telefono</label>
                            <input style="font-weight: bold" type="text" readonly class="form-control-plaintext" id="floatingPassword" name="telefono"
                                placeholder="Introduce tu Telefono" value="<?php echo e(auth()->user()->telefono); ?>">
                            <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="alert alert-danger mt-2"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <?php else: ?>
                            <label class="comensaleslabel mt-2 mb-2" for="cantidad-comensales">E-mail</label>
                            <input style="font-weight: bold" type="email" class="form-control" id="floatingInput" name="email"
                                placeholder="Introduce tu email">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="alert alert-danger mt-2"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <label class="comensaleslabel mt-2 mb-2" for="cantidad-comensales">Nombre</label>
                            <input style="font-weight: bold" type="text" class="form-control" id="floatingPassword" name="nombre"
                                placeholder="Introduce tu Nombre">
                            <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="alert alert-danger mt-2"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <label class="comensaleslabel mt-2 mb-2" for="cantidad-comensales">Telefono</label>
                            <input style="font-weight: bold" type="tel" class="form-control" id="floatingPassword" name="telefono"
                                placeholder="Introduce tu Telefono">
                            <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="alert alert-danger mt-2"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <?php endif; ?>

                        
                    </div>


                    <button type="submit" class="mt-3 mb-5 btn btn-primary w-25 col-md-6">RESERVAR</button>
                </form>
                <div id='calendar'></div>
            </section>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<script>
    //     {/* function name(params) {
    //     let a = document.getElementsByClassName('estoyAqui')
    //     a.classList.remove("d-none");
    //     // a.classList.add("verde");
    // } */}
    function chequeoCuenta() {
        let contenedor = document.getElementsByClassName('estoyAqui')[0];
        let prueba = document.getElementById("cuentaValor").checked;
        if (prueba) {

            contenedor.classList.remove('d-none');
            // console.log(contenedor.classList);
            console.log(prueba);
        } else {
            contenedor.classList.add('d-none');
        }
    }
</script>

<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medac-laravel\resources\views/confirmar.blade.php ENDPATH**/ ?>