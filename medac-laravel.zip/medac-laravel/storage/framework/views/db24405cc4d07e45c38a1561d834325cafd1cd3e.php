<?php $__env->startSection('content'); ?>
    <main>
        <div class="mainConfirmacion row justify-content-center">
            <section class="col-12 col-md-6 bg-light text-dark ">
                <form action="/areaPersonal" method="get" class="row justify-content-center">
                    <div class="text-center">
                        <p>Iniciar Sesion</p>
                        <p>ESTAS EN LOGIN2</p>
                    </div>
                    <div class="justify-content-center text-center">
                        <label class="comensaleslabel mt-2 mb-2" for="cantidad-comensales">E-mail</label>
                        <input type="email" class="form-control" id="floatingInput" name="mail"
                            placeholder="Introduce tu email">
                        <label class="comensaleslabel mt-2 mb-2" for="cantidad-comensales">Contraseña</label>
                        <input type="password" class="form-control" id="floatingPassword" name="password"
                            placeholder="Introduce tu Contraseña">

                        <button type="submit" class="mt-5 mb-5 btn btn-primary w-25 col-md-6">INICIAR SESION</button>
                </form>
            </section>
        </div>
    </main>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medac-laravel\resources\views/login2.blade.php ENDPATH**/ ?>