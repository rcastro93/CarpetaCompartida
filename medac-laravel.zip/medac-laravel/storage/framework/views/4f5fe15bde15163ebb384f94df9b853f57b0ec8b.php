<?php $__env->startSection('content'); ?>
    <h1 class="text-center">Bienvenido a tus Reservas, <?php echo e(auth()->user()->name); ?></h1>
    <?php $__currentLoopData = $reservas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reserva): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card mx-auto col-md-2 m-3 p-3">
            <h2 class="text-center"><?php echo e($reserva->horario->fecha); ?></h2>
            <?php if($reserva->cliente == null): ?>
                
                <h3>Nombre: <?php echo e($reserva->invitado->nombre); ?></h3>
            <?php else: ?>
                <h3>Nombre: <?php echo e($reserva->cliente->name); ?></h3>
            <?php endif; ?>
            <h3>Número de Comensales: <?php echo e($reserva->num_personas); ?></h3>
            <h3>Nº de tarjeta: <?php echo e($reserva->num_tarjeta); ?></h3>
            <h3>Menu elegido: <?php echo e($reserva->menuReservado->nombre); ?></h3>
            <td>
                <form class="text-center p-3" method="post" action="<?php echo e(route('reserva.delete', $reserva)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-danger" type="submit" rel="tooltip">
                        Eliminar Reserva
                    </button>
                </form>
            </td>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medac-laravel\resources\views/misReservas.blade.php ENDPATH**/ ?>