<?php

namespace Database\Factories;

use App\Models\Horario;
use App\Models\Menu;
use App\Models\Tarjeta;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;
use PhpParser\Node\NullableType;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Reserva>
 */
class ReservaFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition()
    {
        $vari = fake()->randomElement(User::all());
        do {
            $vari = fake()->randomElement(User::all());
            $result = Tarjeta::where('id_cliente', $vari["id"])->get("num_tarjeta");
        } while ($result->first() == null);

        return [
            "id_mesa" => "1",
            "num_personas" => fake()->numberBetween(1, 12),
            "id_cliente" => $vari->id,
            "id_invitado" => null,
            "id_menu" => fake()->randomElement(Menu::all())["id"],
            "fecha_reserva" => fake()->randomElement(Horario::all())["id"],
            "num_tarjeta" => $result->first(),
        ];
    }
}
