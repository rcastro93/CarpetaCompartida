@extends('layouts/layout')
@section('content')
    <main>
        <section class="map card">Ubicacion Mapa</section>
        <section>
            <div class="confirmacionmail card">
                <p>Tu reserva ha sido confirmada</p>
            </div>
            <div>
                <p>Te hemos mandado un mail con la confirmacion y todos los datos necesarios</p>
            </div>
            <form action="enviarmail.php">
                <div>
                    <label for="mailcomensal">Mail</label>
                    <input type="text" placeholder="Introduce el mail de otro comensal" id="mailcomensal"
                        name="mailcomensal">
                </div>
                <div>
                    <button type="submit">Enviar</button>
                </div>
            </form>
        </section>
        <section class="reseñas">
            <div>
                <p>Lee algunas de nuestras reseñas</p>
            </div>
            <div>Reseñas Google y Tripadvisor</div>
            <div>
                <p>Fotos</p>
            </div>
            <div>Fotos del restaurante extraidas de la web</div>
        </section>
    </main>
@endsection