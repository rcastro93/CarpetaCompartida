@extends('layouts/layout')
@section('content')
        <main>
            <div class="mainConfirmacion row">
                <section class="col-12 col-md-6">
                    <div class="mensajeConfirmacion">
                        <p class="titularConfirmacion mt-10"> Bienvenido a tu cuenta, @user</p>
                        <br>
                        <p class="">
                            Aqui tienes un resumen de tus ultimas visitas a Noor
                        </p>
                    </div>
                    
                </section>
                <section class="col-12 col-md-6 bg-light text-dark ">
                    <form action="success.html" method="get" class="row justify-content-center">
                        <div>
                            <label class="comensaleslabel mt-2 mb-2" for="cantidad-comensales">Cambiar E-mail</label>
                            <input type="email" class="form-control" id="floatingInput" name="mail"
                                placeholder="Introduce tu email">
                                <label class="comensaleslabel mt-2 mb-2" for="cantidad-comensales">Cambiar Nombre</label>
                            <input type="text" class="form-control" id="floatingPassword" name="password"
                                placeholder="Introduce tu Nombre">
                                <label class="comensaleslabel mt-2 mb-2" for="cantidad-comensales">Cambiar Telefono</label>
                            <input type="tel" class="form-control" id="floatingPassword" name="password"
                                placeholder="Introduce tu Telefono">
                        </div>


                        <button type="submit"
                            class="mt-5 mb-5 btn btn-primary w-25 col-md-6">CONFIRMAR</button>
                    </form>
                </section>
            </div>
        </main>
@endsection