@extends('layouts/layout')
@section('content')
    <h1 class="text-center">Bienvenido a tus Reservas, {{ auth()->user()->name }}</h1>
    @foreach ($reservas as $reserva)
        <div class="card mx-auto col-md-2 m-3 p-3">
            <h2 class="text-center">{{ $reserva->horario->fecha }}</h2>
            @if ($reserva->cliente == null)
                {{-- {{ dd($reserva->invitado) }} --}}
                <h3>Nombre: {{ $reserva->invitado->nombre }}</h3>
            @else
                <h3>Nombre: {{ $reserva->cliente->name }}</h3>
            @endif
            <h3>Número de Comensales: {{ $reserva->num_personas }}</h3>
            <h3>Nº de tarjeta: {{ $reserva->num_tarjeta }}</h3>
            <h3>Menu elegido: {{ $reserva->menuReservado->nombre }}</h3>
            <td>
                <form class="text-center p-3" method="post" action="{{ route('reserva.delete', $reserva) }}">
                    @csrf
                    @method('DELETE')
                    <button class="btn btn-danger" type="submit" rel="tooltip">
                        Eliminar Reserva
                    </button>
                </form>
            </td>
        </div>
    @endforeach
@endsection
