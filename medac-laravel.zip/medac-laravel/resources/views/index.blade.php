@extends('layouts/layout')
@section('content')
    <main class="text-center">
        <section class="col  display-3">
            <div class="justify-content-around">
                <h1 class="mt-7 mb-5">Bienvenido a noor</h1>
                <img class="col-md-12 img-fluid" src="img/restBienvenida.jpg" alt="restaurante">
            </div>
        </section>
        <section class="intro row justify-content-around">
            <div class="col-md-11 text-center">
                <p class="mt-5 justify-content-around">En 2016 el chef cordobés Paco Morales ilumina Noor con la vuelta a su Córdoba natal, a sus
                    orígenes,
                    para alumbrar una propuesta única y personal de cocina contemporánea andalusí. El legado
                    culinario de Al-Ándalus recuperado
                    en clave contemporánea.
                    <br>
                    La propuesta culinaria se inspira en la historia y el pensamiento de las culturass,
                    cuyo hito capital fue el Califato de Abderramán III, que convirtió Córdoba en la ciudad más
                    culta y avanzada de su época.
                </p>
            </div>
            <div class="col-md-12 text-center">
                <img class="img-fluid mt-5" src="img/introimg.jpg" alt="introimg">
            </div>
        </section>
        <section class="display-1">
            <div>
                <p class="mt-5">TEMPORADAS</p>
            </div>
        </section>
        <section class="row justify-content-center text-center">
            <div><img class="img-fluid col-md-6" src="img/alandalus.png" alt="Al-Ándalus"></div>
            <div class="col-md-11 ">
                <p class="mt-5">Temporada inmersa en la culinaria andalusí del siglo X, etapa de esplendor político,
                    cultural y comercial propiciada por el Califato de Córdoba. Noor inició su propio universo
                    particular a
                    través de tres menús degustación: Qurtuba, Madinat Al-Zahra y Al-Ándalus</p>.
            </div>
            <div><img class="img-fluid mt-5" src="img/alandaluscomida.jpg" alt="alandaluscomida"></div>
        </section>
        <section class="col justify-content-around">
            <div><img class="img-fluid mt-5 justify-content-around" src="img/taifas.png" alt="taifas"></div>
            <div class="row justify-content-around">
                <p class="col-md-11 text-center mt-5">Noor continúa su avance en el tiempo. En este año 1 recupera los
                    <span>sabores perdidos</span> de los tres Reinos
                    de Taifas, y sus culturas, que más perduraron tras la disolución y caída del Califato de Córdoba en
                    1031. Son los que dan nombre a las<span>tres alternativas de menú</span>:
                    <span>Eslava, Bereber y Andalusí</span>.
                </p>
            </div>
            <div class="row justify-content-around">
                <img class="col-md-11 img-fluid w-80 mb-2 rounded mt-5" src="img/taifascomida1.jpg" alt="">
                <div class="col-5">
                    <span></span>
                </div>
                <img class="col-md-11 img-fluid w-80 rounded" src="img/taifascomida2.jpg" alt="">
            </div>
        </section>
        <section class="nazari">
            <div><img class="img-fluid mt-5" src="img/nazari.png" alt="nazari"></div>
            <div class="descrip">
                <p class="col-md-11 justify-content-around mt-5">
                Noor conserva su línea de no integrar ingredientes del Nuevo Mundo americano en su cocina del siglo XIV
                que, aún sin patata, tomate, maíz o cacao ... da un
                <span>último salto mortal</span>
                para que su propuesta
                gastronómica continúe tan
                <span>inigualable y rotunda</span>
                como en el Año 1.</p>
            </div>
            <div><img class="img-fluid mb-2 mt-5" src="img/nazarifood.jpg" alt=""></div>
            <div><img class="img-fluid" src="img/nazarifood2.jpg" alt=""></div>
        </section>
    </main>
    @endsection