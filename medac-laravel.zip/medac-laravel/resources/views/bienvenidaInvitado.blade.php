@extends('layouts/layout')
@section('content')
    <main>
        <div class="mainConfirmacion row">

            <section class="col-12 col-md-3">
                {{-- {{ dd($resultados[1]->last()->invitado->nombre) }} --}}
                <h2 class="text-center">TU RESERVA HA SIDO CONFIRMADA</h2>

                <h1 class="text-center">{{ $resultados[1]->last()->invitado->nombre }}</h1>
            </section>
            <section class="col-12 col-md-3 ">
                <h2 class="text-center">Estos son los datos de tu ultima reserva:</h2>
                <div style="color: black" class="card p-4 text-center">

                    <h2>{{ $resultados[1]->last()->horario->fecha}}</h2>
                    {{-- <h4  >{{ $invitado[0]->reserva->horario->fecha }}</h4> --}}
                    <h3>Hora: {{ $resultados[1]->last()->horario->hora }}</h3>
                    <h3>Número de Comensales: {{ $resultados[1]->last()->num_personas }}</h3>
                    <h3>Nº de tarjeta: {{ $resultados[1]->last()->num_tarjeta }}</h3>
                    <h3>Menu elegido: {{ $resultados[1]->last()->menuReservado->nombre }}</h3>
                </div>
            </section>
            <section class="col-12 col-md-6 bg-light text-dark ">
                <h2 class="text-center">¿Quieres registrarte para ahorrarte tiempo?</h2>

                <form method="POST" action="{{ route('register') }}">
                    @csrf

                    <div class="row mb-3">
                        <label for="name" class="col-md-4 col-form-label text-md-end">{{ __('Nombre') }}</label>

                        <div class="col-md-6">
                            <input id="name" type="text" readonly class="form-control-plaintext @error('name') is-invalid @enderror"
                                name="name" required autocomplete="name" value={{ $resultados[1]->last()->invitado->nombre }}>

                            @error('name')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label for="email" class="col-md-4 col-form-label text-md-end">{{ __('Email') }}</label>

                        <div class="col-md-6">
                            <input id="email" type="email" readonly class="form-control-plaintext @error('email') is-invalid @enderror"
                                name="email" value="{{ $resultados[1]->last()->invitado->email }}" required autocomplete="email">

                            @error('email')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label for="telefono" class="col-md-4 col-form-label text-md-end">{{ __('Telefono') }}</label>

                        <div class="col-md-6">
                            <input id="telefono" type="text"
                            readonly class="form-control-plaintext @error('telefono') is-invalid @enderror" name="telefono"
                                value="{{ $resultados[1]->last()->invitado->telefono}}" required autocomplete="telefono">

                            @error('telefono')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label for="password" class="col-md-4 col-form-label text-md-end">{{ __('Contraseña') }}</label>

                        <div class="col-md-6">
                            <input id="password" type="password"
                                class="form-control @error('password') is-invalid @enderror" name="password" required
                                autocomplete="new-password">

                            @error('password')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label for="password-confirm"
                            class="col-md-4 col-form-label text-md-end">{{ __('Confirmar Contraseña') }}</label>

                        <div class="col-md-6">
                            <input id="password-confirm" type="password" class="form-control" name="password_confirmation"
                                required autocomplete="new-password">
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label for="password"
                            class="col-md-4 col-form-label text-md-end">{{ __('Datos de tarjeta') }}</label>

                        <div class="col-md-6">
                            <input placeholder="NUMERO TARJETA" id="num_tarjeta" type="text"
                            readonly class="form-control-plaintext mb-2  @error('num_tarjeta') is-invalid @enderror" name="num_tarjeta"

                                required autocomplete="num_tarjeta" value="{{ $resultados[0]['num_tarjeta'] }}">
                                {{-- {{ dd($resultados[0]) }} --}}
                                <input placeholder="MES CADUCIDAD" id="mes_caducidad" type="text"
                                readonly class="form-control-plaintext mb-2  @error('mes_caducidad') is-invalid @enderror" name="mes_caducidad"
                                required autocomplete="mes_caducidad" value="{{ $resultados[0]['mes'] }}">
                            <input placeholder="AÑO CADUCIDAD" id="anyo_caducidad" type="text"
                            readonly class="form-control-plaintext mb-2  @error('anyo_caducidad') is-invalid @enderror"
                                name="anyo_caducidad" required autocomplete="anyo_caducidad" value="{{ $resultados[0]['anyo'] }}">
                            <input placeholder="CVV" id="cvv" type="text"
                            readonly class="form-control-plaintext @error('cvv') is-invalid @enderror" name="cvv" required
                                autocomplete="cvv" value="{{ $resultados[0]['cvv'] }}">

                            @error('password')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="row mb-2">
                        <div class="col-md-6 offset-md-4">
                            <button type="submit" class="btn btn-primary">
                                {{ __('Registrarse') }}
                            </button>
                        </div>
                    </div>

                </form>
            </section>
        </div>
    </main>
@endsection
