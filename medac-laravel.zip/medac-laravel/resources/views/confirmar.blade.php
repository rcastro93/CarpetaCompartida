@extends('layouts/layout')
@section('content')
@php
        // print_r($prueba['horarios']);
        $guardado = [];
        foreach ($prueba as $a) {
            # code...
            foreach ($a as $key ) {
                # code...
                if ($key->fecha != "") {
                    # code...
                    array_push($guardado, $key->fecha);
                }
            }
        }
        // print_r($guardado)
        $events = json_encode($guardado);
  // Almacenar en SessionStorage
  echo "<script>sessionStorage.setItem('events', '$events');</script>";

    @endphp
    <script>
        var events = JSON.parse(sessionStorage.getItem('events'));
// console.log(events);
        // console.log($prueba);
        let prueba2 = [];
        for (let index = 0; index < events.length; index++) {
            // console.log(events[0]);
            prueba2.push({
                id: events[index],
                title: 'DISPONIBLE',
                start: events[index],
                end: events[index],
                allDay: true,
            });
        }
        console.log(prueba2);
        document.addEventListener('DOMContentLoaded', function() {

            var calendarEl = document.getElementById('calendar');
            var calendar = new FullCalendar.Calendar(calendarEl, {
                events: prueba2,

                customButtons: {
                    myCustomButton: {
                        text: 'custom',
                        click: function() {
                            alert('clicked the custom button!');
                        }
                    }
                },
                buttonIcons: {
                    prev: 'left-single-arrow',
                    next: 'right-single-arrow',
                },
                eventContent: function(eventInfo) {
                    var backgroundColor = 'green';
                    var borderColor = 'green';
                    var textColor = 'white';
                    return {
                        html: `<div style='background-color:${backgroundColor};color:${textColor};'>${eventInfo.event.title}</div>`
                    };
                },
                eventClick: function(info) {
                    alert('Event: ' + info.event.title);
                },
            });
            calendar.render();
        });
    </script>
    <main>
        <div class="mainConfirmacion row">
            <section class="col-12 col-md-6">
                <div class="mensajeConfirmacion">
                    {{-- <p class="titularConfirmacion mt-10"> ¡Buenas noticias!</p> --}}
                    <br>
                    <p class="">
                        {{-- El dia seleccionado tiene disponibilidad --}}
                        <br><br>
                        Rellene los formularios y confirmaremos
                        su <br><b>reserva</b>
                    </p>
                </div>

            </section>
            <section class="col-12 col-md-6 bg-light text-dark ">
                <form action="/success" method="post" class="row justify-content-center">
                    @csrf
                    <div class="text-center">
                        <p>Seleccione el turno de servicio y la cantidad de comensales</p>
                        <label class="comensaleslabel mb-3" for="turno-servicio">Selecciona tu menu:</label>
                        <select name="menu" class="seleccion w-25">
                            @foreach ( $prueba["menus"]  as $valor)
                                <option value="{{ $valor->id }}">{{ $valor->nombre }}</option>
                            @endforeach
                        </select>
                        <br>
                        <label class="comensaleslabel mb-3" for="turno-servicio">Selecciona tu tarjeta:</label>
                        <select name="tarjeta" class="seleccion w-25">
                            @foreach ( auth()->user()->tarjetas  as $valor)
                            <option value=" {{ $valor->num_tarjeta }} ">{{ $valor->num_tarjeta }}</option>
                            @endforeach
                        </select>
                        <br>
                        <label class="comensaleslabel mb-3" for="turno-servicio">Selecciona tu horario:</label>
                        <br>
                        <select class="w-90 p-3" name="horario" class="seleccion">
                            @foreach ( $prueba["horarios"]  as $valor)
                                <option value="{{ $valor->id }}">{{ $valor->fecha }} / {{ $valor->hora }}</option>
                            @endforeach
                        </select>
                        <br>
                        <br>
                        <label class="comensaleslabel mb-3" for="cantidad-comensales">Selecciona el número de
                            Comensales:</label>
                        <select name="comensales" class="cantidad-comensal w-25">
                            <option value="0">--</option>
                            <option value="1">Uno</option>
                            <option value="2">Dos</option>
                            <option value="3">Tres</option>
                            <option value="4">Cuatro</option>
                            <option value="5">Cinco</option>
                            <option value="6">Seis</option>
                        </select>
                    </div>
                    <div>
                        @if (auth()->user())
                            <label class="comensaleslabel mt-2 mb-2" for="cantidad-comensales">E-mail</label>
                            <input style="font-weight: bold" type="email" readonly class="form-control-plaintext font-weigth-bold" id="floatingInput" name="email"
                                placeholder="Introduce tu email" value="{{ auth()->user()->email }}">
                            @error('email')
                                <p class="alert alert-danger mt-2">{{ $message }}</p>
                            @enderror
                            <label class="comensaleslabel mt-2 mb-2" for="cantidad-comensales">Nombre</label>
                            <input style="font-weight: bold" type="text" readonly class="form-control-plaintext" id="floatingPassword" name="nombre"
                                placeholder="Introduce tu Nombre" value="{{ auth()->user()->name }}">
                            @error('nombre')
                                <p class="alert alert-danger mt-2">{{ $message }}</p>
                            @enderror
                            <label class="comensaleslabel mt-2 mb-2" for="cantidad-comensales">Telefono</label>
                            <input style="font-weight: bold" type="text" readonly class="form-control-plaintext" id="floatingPassword" name="telefono"
                                placeholder="Introduce tu Telefono" value="{{ auth()->user()->telefono }}">
                            @error('telefono')
                                <p class="alert alert-danger mt-2">{{ $message }}</p>
                            @enderror
                        @else
                            <label class="comensaleslabel mt-2 mb-2" for="cantidad-comensales">E-mail</label>
                            <input style="font-weight: bold" type="email" class="form-control" id="floatingInput" name="email"
                                placeholder="Introduce tu email">
                            @error('email')
                                <p class="alert alert-danger mt-2">{{ $message }}</p>
                            @enderror
                            <label class="comensaleslabel mt-2 mb-2" for="cantidad-comensales">Nombre</label>
                            <input style="font-weight: bold" type="text" class="form-control" id="floatingPassword" name="nombre"
                                placeholder="Introduce tu Nombre">
                            @error('nombre')
                                <p class="alert alert-danger mt-2">{{ $message }}</p>
                            @enderror
                            <label class="comensaleslabel mt-2 mb-2" for="cantidad-comensales">Telefono</label>
                            <input style="font-weight: bold" type="tel" class="form-control" id="floatingPassword" name="telefono"
                                placeholder="Introduce tu Telefono">
                            @error('telefono')
                                <p class="alert alert-danger mt-2">{{ $message }}</p>
                            @enderror
                        @endif

                        {{-- <input type="checkbox" name="account" id="cuentaValor" onclick="chequeoCuenta()"> ¿Quieres
                        crear una cuenta?
                    </div>
                    <div class="estoyAqui d-none">
                        <input type="tel" class="form-control" id="floatingPassword" name="password"
                            placeholder="Introduce tu Contraseña si quieres crear una cuenta">
 --}}
                    </div>


                    <button type="submit" class="mt-3 mb-5 btn btn-primary w-25 col-md-6">RESERVAR</button>
                </form>
                <div id='calendar'></div>
            </section>
        </div>
    </main>
@endsection

<script>
    //     {/* function name(params) {
    //     let a = document.getElementsByClassName('estoyAqui')
    //     a.classList.remove("d-none");
    //     // a.classList.add("verde");
    // } */}
    function chequeoCuenta() {
        let contenedor = document.getElementsByClassName('estoyAqui')[0];
        let prueba = document.getElementById("cuentaValor").checked;
        if (prueba) {

            contenedor.classList.remove('d-none');
            // console.log(contenedor.classList);
            console.log(prueba);
        } else {
            contenedor.classList.add('d-none');
        }
    }
</script>
