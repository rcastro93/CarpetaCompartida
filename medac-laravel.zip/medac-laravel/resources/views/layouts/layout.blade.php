<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    @vite(['resources/sass/app.scss', 'resources/js/app.js'])

    <script src="https://code.jquery.com/jquery-3.6.3.js" integrity="sha256-nQLuAZGRRcILA+6dMBOvcRh5Pe310sBpanc6+QBmyVM=" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.0.2/index.global.min.js"></script>
    <title>noor Restaurant</title>
</head>

<body>
    <header>
        <nav class="headerDiv">
            <input type="checkbox" id="minimenu">
            <label class="labelraro" for="minimenu">&#9776;</label>
            <div class="logoPrincipal">
                <a href="/"> <img src="img/noor.svg" style="width: 18rem" alt=""></a>
                {{-- <a href="/"> <img src="img/logo-sinfondoplano.png" alt=""></a> --}}
            </div>
            <ul>


                @if (auth()->user())
                    <div class="Reserva">
                        <li><a href="/confirmar">Reservar</a></li>
                    </div>
                    <div class="Contacto">
                        <li><a href="/misReservas">MisReservas</a></li>
                    </div>
                    <div class="Contacto">
                        <li><a href="{{ route('login.delete') }}">CerrarSesion</a></li>
                    </div>
                    <div class="Contacto">
                        <li><a href="{{ route('addTarjetaVista') }}">Añadir Tarjeta</a></li>
                    </div>
                @else
                    <div class="Reserva">
                        <li><a href="/confirmarInvitado">Reservar como Invitado</a></li>
                    </div>
                    <div class="Contacto">
                        <li><a href="/registro">Registrarse</a></li>
                    </div>
                    <div class="Contacto">
                        <li><a href="/entrar">Login</a></li>
                    </div>
                @endif
                <div class="Contacto">
                    <li><a href="/contacto">Contacto</a></li>
                </div>


            </ul>
        </nav>
    </header>
    @yield('content')
    <footer>
        <div class="namefooter">
            <p>
            <nav>
                <a href="/">Noor Restaurant</a>
            </nav>
            </p>
        </div>
        <div class="footernav">
            <p>
            <nav>
                <a href="/login">Trabaja con Nosotros</a>
                <a href="#">Encuentranos</a>
                <a href="#">Redes Sociales</a>
            </nav>
            </p>
        </div>
    </footer>
</body>

</html>
