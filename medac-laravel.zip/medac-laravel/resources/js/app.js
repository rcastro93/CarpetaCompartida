import './bootstrap';
const swal = window.swal = require('sweetalert2');
