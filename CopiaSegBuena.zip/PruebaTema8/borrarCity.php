<?php
    include 'utils.php';

    if(isset($_POST['city'])){
        $ciudad=$_POST['city'];
        $nombre=$_POST['nombre'];
        $res=borrarCiudad($ciudad, $nombre);
        echo $res;
    }
    else{
        die("No se ha obtenido ninguna ciudad");
    }
?>