<?php

function conexionBD()
{
    $servername = "localhost:3309";
    $username = "root";
    $password = "654456";
    $dbname = "world";

    $conexion = mysqli_connect($servername, $username, $password, $dbname);

    if (!$conexion) {
        die('Conexion fallida: ' . mysqli_connect_error());
    }

    return $conexion;
}

function getCountries()
{
    $conexion = conexionBD();

    $sql = "SELECT Name, Code FROM country";
    $result = mysqli_query($conexion, $sql);

    return mysqli_fetch_all($result, MYSQLI_ASSOC);
}

function formatOptionsCountries()
{
    $countries = getCountries();

    $options = "";
    foreach ($countries as $row) {
        $options .= "<option value='" . $row["Code"] . "'>" . $row["Name"] . "</option>";
    }

    return $options;
}

function getCitiesByCountry($CodeCountry)
{
    $conexion = conexionBD();

    $sql = "SELECT ci.ID, ci.CountryCode, ci.Name FROM city ci, country co WHERE ci.CountryCode=co.Code AND co.Code='" . $CodeCountry . "'";
    $result = mysqli_query($conexion, $sql);

    return mysqli_fetch_all($result, MYSQLI_ASSOC);
}

function saveCity($ciudad, $nombre)
{
    $conexion = conexionBD();

    $sql = "UPDATE city SET Name='" . $nombre . "' WHERE ID='" . $ciudad . "'";
    $result = mysqli_query($conexion, $sql);

    if ($result) {
        echo "Ciudad: " . $nombre . " se ha actualizado correctamente";
    } else {
        echo "No se ha podido guardar la ciudad: " . $ciudad;
    }
}

function insertCity($pais, $ciudad)
{
    $conexion = conexionBD();

    $sql = "INSERT INTO city(Name,CountryCode) VALUES('" . $ciudad . "','" . $pais . "')";
    $result = mysqli_query($conexion, $sql);

    if ($result) {
        echo "Ciudad: " . $ciudad . " se ha insertado correctamente";
    } else {
        echo "No se ha podido insertar la ciudad: " . $ciudad;
    }
}

function formatTableCities($CodeCountry)
{
    $cities = getCitiesByCountry($CodeCountry);

    $table = "<table border='1'><th>Ciudades</th>";
    foreach ($cities as $row) {
        $table .= "<tr><td>" . $row["Name"] . "</td></tr>";
    }
    $table .= "</table>";

    return $table;
}

function formatInputsCities($CodeCountry)
{
    $cities = getCitiesByCountry($CodeCountry);

    $result = "<div><Ciudades del país " . $CodeCountry . "</div>";

    foreach ($cities as $row) {
        $result .= "<input type='text' id='" . $row['ID'] . "' name='" . $row['CountryCode'] . "' value=" . $row["Name"] . "></input>";
        $result .= "<button onclick='saveCiudadJquery(" . $row['ID'] . ")'>Guardar</button>";
        $result .= "<button onclick='borrarCiudadJquery(" . $row['ID'] . ")'>Borrar</button><br>";
    }

    return $result;
}

function borrarCiudad($ciudad, $nombre)
{
    $conexion = conexionBD();

    $sql = "DELETE FROM city WHERE Name='" . $nombre . "' AND ID='" . $ciudad . "'";
    $result = mysqli_query($conexion, $sql);

    if ($result) {
        echo "Ciudad: " . $nombre . " se ha borrado correctamente";
    } else {
        echo "No se ha podido borrar la ciudad: " . $ciudad;
    }
}

function backUp($ciudades)
{
    // print_r($ciudades[0]['id']);
    $conexion = conexionBD();

    $nombreTabla = "Tabla_" . date("Ymd_His"); // generar nombre de tabla con fecha actual
    $sql = "CREATE TABLE $nombreTabla (nombre VARCHAR(255), id INT, PRIMARY KEY(id), UNIQUE (id))";
    mysqli_query($conexion, $sql);

    $count = 0;
    $savepoint = "savepoint_1";
    mysqli_begin_transaction($conexion);
    try {
        foreach ($ciudades as $element) {
            if ($count >= 13) {
                $nombre = $element['nombre'];
                $id = 1;
                $sql = "INSERT INTO $nombreTabla (nombre, id) VALUES ('$nombre', '$id')";
                mysqli_query($conexion, $sql);
            } else {
                $nombre = $element['nombre'];
                $id = $element['id'];
                $sql = "INSERT INTO $nombreTabla (nombre, id) VALUES ('$nombre', '$id')";
                mysqli_query($conexion, $sql);
                $count++;
                if ($count % 5 == 0) {
                    $savepoint = "savepoint_" . ($count / 5);
                    mysqli_query($conexion, "SAVEPOINT $savepoint");
                }
            }
        }
        mysqli_commit($conexion);
    } catch (Exception $e) {
        mysqli_query($conexion, "ROLLBACK TO $savepoint");
        mysqli_commit($conexion);
        throw $e;
    }
}
