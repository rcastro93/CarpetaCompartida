<?php
include("json.php");
include 'utils.php';

if (isset($_POST['ciudades'])) {
    $myArrayJSON = $_POST['ciudades'];
    $myArray = json_decode($myArrayJSON, true);
    // die($_POST['ciudades']);
    // print_r($myArray);
    backUp($myArray);
    // echo $res;
    
} else {
    die("No se ha obtenido ninguna ciudad");
}
