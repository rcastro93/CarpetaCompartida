$(document).ready(function(){
    peticionCiudadesJquery();

    $('#selectCountry').change(function() {
        peticionCiudadesJquery();
    });
});

var http_request = false;

function peticionCiudades(url) {

    http_request = false;

    // Instanciamos el objeto XMLHttpRequest
    if (window.XMLHttpRequest) { // Mozilla, Safari,...
        http_request = new XMLHttpRequest();
        if (http_request.overrideMimeType) {
            http_request.overrideMimeType('text/xml');
        }
    } else if (window.ActiveXObject) { // IE
        try {
            http_request = new ActiveXObject("Msxml2.XMLHTTP");
        } catch (e) {
            try {
                http_request = new ActiveXObject("Microsoft.XMLHTTP");
            } catch (e) {}
        }
    }

    // Comprobamos si ha fallado la instanciación
    if (!http_request) {
        alert('Falla :( No es posible crear una instancia XMLHTTP');
        return false;
    }

    // Objeto queda escuchando hasta que se reciba la respuesta del servidor
    http_request.onreadystatechange = mostrarCiudades;

    // Realizamos la petición
    http_request.open('POST', url, true);

    // Recuperamos el país seleccionado
    var country=document.getElementById("selectCountry");

    // Datos para enviar al servidor por POST
    var formData = new FormData();
    formData.append("selectCountry", country.value);
    // Enviar la petición
    http_request.send(formData);
}

function mostrarCiudades() {
    // Comprobamos que la respuesta ha sido correctamente recibida al servidor
    if (http_request.readyState == 4) {
        // COmprobamos la respuesta de la petición HTTP
        if (http_request.status == 200) {
            // Obtenemos el elemento para añadir la tabla
            var element = document.getElementById("tableCities");
            // Anexamos la tabla
            element.innerHTML = http_request.responseText;
        } else {
            alert('Hubo problemas con la petición.');
        }
    }
}

function peticionCiudadesJquery() {

    // Recuperamos el país seleccionado
    var country=document.getElementById("selectCountry");
    // console.log("aasdasd");
    // Método $.ajax de Jquery
    // console.log($("#selectCountry option:selected").val());
    $.ajax({
        type: "POST",
        url: 'getCities.php',
        // Datos para enviar al servidor por POST
        data: { selectCountry : country.value },
        success: function(response)
        {
            // var back = document.getElementById('botonBackUp');
            // var codigo = $("#selectCountry option:selected").val();
            // // console.log(codigo);
            // back.innerHTML= '<button onclick="realizarBackUp('+codigo+')">Realizar BackUp</button>';
            var countrySpan= document.getElementById("paisSelected");
            countrySpan.innerHTML=$("#selectCountry option:selected" ).text();

            // Obtenemos el elemento para añadir la tabla
            var element = document.getElementById("inputsCities");
            // Anexamos la tabla
            element.innerHTML = response;
            document.getElementById('insertCity').style.display = 'none'; 
        }
    });
}

    function realizarBackUp(){
        // console.log("HA ENTRADO");
        var codigo = $("#selectCountry option:selected").val();
        var grupo2 = document.getElementsByName(codigo);
        var pruebaFinal = [];
        
        // console.log(Array.from(pruebaFinal));
        var grupo3 = Array.from(grupo2);
        for (let i = 0; i<grupo3.length; i++){
            pruebaFinal[i] = {nombre: grupo3[i].value, id : grupo3[i].id};
        }
        // console.log(grupo3);
        console.log(pruebaFinal);
        var myArrayJSON = JSON.stringify(pruebaFinal);
        
        $.ajax({
            type: "POST",
            url: 'backUp.php',
            // Datos para enviar al servidor por POST
            data: { ciudades : myArrayJSON,
            },
            success: function(response)
            {
                alert("Se ha realizado la copia de seguridad");
            }
        });

        
    }

    function saveCiudadJquery(ciudad) {
   
        // Recuperamos el país seleccionado
        var nombre=document.getElementById(ciudad);

        // Método $.ajax de Jquery
        $.ajax({
            type: "POST",
            url: 'saveCity.php',
            // Datos para enviar al servidor por POST
            data: { city : ciudad,
                nombre : nombre.value
            },
            success: function(response)
            {
                alert(response);
                peticionCiudadesJquery();
            }
        });
    }

    function borrarCiudadJquery(ciudad) {

        // Recuperamos el país seleccionado
        var nombre=document.getElementById(ciudad);

        // Método $.ajax de Jquery
        $.ajax({
            type: "POST",
            url: 'borrarCity.php',
            // Datos para enviar al servidor por POST
            data: { city : ciudad,
                nombre : nombre.value
            },
            success: function(response)
            {
                alert(response);
                peticionCiudadesJquery();
            }
        });
    }

    function mostrarInsertCiudadJquery() {
        document.getElementById('insertCity').style.display = 'block';     
    }

    function insertCiudadJquery() {

        // Recuperamos el país seleccionado
        var pais=document.getElementById("selectCountry");

        // Recuperamos la ciudad introducida
        var ciudad=document.getElementById("insert");
        // Método $.ajax de Jquery
        $.ajax({
            type: "POST",
            // Donde se envía los datos: como el action
            url: 'newCity.php',
            // Datos para enviar al servidor por POST
            data: { country : pais.value,
                    city : ciudad.value
            },
            //devuelve la respuesta si todo a ido bien
            success: function(response)
            {
                alert(response);
                peticionCiudadesJquery();
                $('#insert').val('');
            }
        });
}