<?php
    include 'utils.php';

    if(isset($_POST['country'])){
        $pais=$_POST['country'];
        $ciudad=$_POST['city'];
        $res=insertCity($pais, $ciudad);
        echo $res;
    }
    else{
        die("No se ha obtenido ninguna ciudad");
    }
?>