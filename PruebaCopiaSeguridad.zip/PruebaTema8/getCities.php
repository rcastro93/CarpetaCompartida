<?php
    include 'utils.php';

    if(isset($_POST['selectCountry'])){
        $country=$_POST['selectCountry'];
        $table=formatInputsCities($country);
        echo $table;
    }
    else{
        die("No se ha seleccionado ningún país");
    }
?>