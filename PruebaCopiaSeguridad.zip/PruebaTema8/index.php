<?php include 'utils.php'; ?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Ajax</title>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="scripts.js"></script>
    </head>

    <body>
        <section style="margin:20px;">
            <h1>Listado de países</h1>
            <form action="getCities.php" method="POST">
                <select id="selectCountry" name="selectCountry">
                    <?=formatOptionsCountries()?>
                </select>
            </form>
        </section>

        <section style="margin:20px;">
            <h1 style="display:inline;">Listado de ciudades del país <span id="paisSelected"></span></h1>
            <button onclick="mostrarInsertCiudadJquery()">Insertar ciudad</button>
            <div id="botonBackUp">

            </div>
            <button onclick="realizarBackUp()">Realizar BackUp</button>
            <div style="margin-top:20px;" id="inputsCities"></div>
            <div id="insertCity">
                <input type='text' id='insert'></input>
                <button onclick='insertCiudadJquery()'>Guardar</button>
                <button onclick='borrarCiudadJquery()'>Borrar</button>
            </div>
        </section>
         
    </body>

</html>